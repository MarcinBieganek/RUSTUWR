import { Fractal } from "projekt3";
// Import the WebAssembly memory at the top of the file.
import { memory } from "projekt3/projekt3_bg";

const CELL_SIZE = 1; // px

// Construct the universe, and get its width and height.
const fractal = Fractal.new();
const width = fractal.width();
const height = fractal.height();

// Give the canvas room for all of our cells and a 1px border
// around each of them.
const button = document.getElementById("draw-button");
const canvas = document.getElementById("fractal-canvas");
canvas.height = (CELL_SIZE + 1) * height + 1;
canvas.width = (CELL_SIZE + 1) * width + 1;

const ctx = canvas.getContext('2d');

const getIndex = (row, column) => {
    return row * width * 3 + (column * 3);
};

const drawFractal = () => {
    const cellsPtr = fractal.cells();
    const cells = new Uint8Array(memory.buffer, cellsPtr, width * height * 3);
  
    ctx.beginPath();
  
    for (let row = 0; row < height; row++) {
      for (let col = 0; col < width; col++) {
        const idx = getIndex(row, col);
        
        ctx.fillStyle = `rgb(${cells[idx]}, ${cells[idx+1]}, ${cells[idx+2]})`;
  
        ctx.fillRect(
          col * (CELL_SIZE + 1),
          row * (CELL_SIZE + 1),
          CELL_SIZE,
          CELL_SIZE
        );
      }
    }
  
    ctx.stroke();
};


button.addEventListener("click", draw);

function draw() {
    fractal.tick();

    drawFractal();
}



/*
const renderLoop = () => {
  //universe.tick();

  //drawGrid();
  //drawCells();

  requestAnimationFrame(renderLoop);
};
*/
//drawCells();
//requestAnimationFrame(renderLoop);