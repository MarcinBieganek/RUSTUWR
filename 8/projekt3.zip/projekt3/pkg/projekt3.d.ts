/* tslint:disable */
/* eslint-disable */
/**
*/
export class Fractal {
  free(): void;
/**
* @returns {number}
*/
  width(): number;
/**
* @returns {number}
*/
  height(): number;
/**
* @returns {number}
*/
  cells(): number;
/**
*/
  tick(): void;
/**
* @returns {Fractal}
*/
  static new(): Fractal;
/**
* @returns {string}
*/
  render(): string;
}
