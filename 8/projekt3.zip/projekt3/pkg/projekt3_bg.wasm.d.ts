/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_fractal_free(a: number): void;
export function fractal_width(a: number): number;
export function fractal_height(a: number): number;
export function fractal_cells(a: number): number;
export function fractal_tick(a: number): void;
export function fractal_new(): number;
export function fractal_render(a: number, b: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number): void;
