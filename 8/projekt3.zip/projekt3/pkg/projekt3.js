import * as wasm from "./projekt3_bg.wasm";
export * from "./projekt3_bg.js";